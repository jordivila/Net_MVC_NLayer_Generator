﻿using System;
using System.ServiceModel;
using SharedContractsLibrary;

namespace AnotherServiceWebRole
{
    [ServiceBehavior(AddressFilterMode = AddressFilterMode.Any,
                     ConfigurationName = "BackEndService", 
                     Namespace = "http://windows.azure.com/samples/2012/02/services")]
    public class BackEndService : IBackEndService
    {
        public string Echo(string text)
        {

            return "Internal::" +
                    DateTime.Now.ToShortTimeString() + "::" +
                    OperationContext.Current.EndpointDispatcher.EndpointAddress + "::" + 
                    (text ?? "NULL");
        }
    }
}
