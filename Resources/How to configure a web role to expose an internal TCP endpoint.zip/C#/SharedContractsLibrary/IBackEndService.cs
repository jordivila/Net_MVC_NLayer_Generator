﻿using System.ServiceModel;

namespace SharedContractsLibrary
{
    [ServiceContract(ConfigurationName = "IBackEndService", Namespace = "http://windows.azure.com/samples/2012/02/services")]
    public interface IBackEndService
    {
        [OperationContract(Action = "Echo", ReplyAction = "EchoResponse")]
        string Echo(string text);
    }

    public interface IBackEndServiceChannel : IBackEndService, IClientChannel { }
}
