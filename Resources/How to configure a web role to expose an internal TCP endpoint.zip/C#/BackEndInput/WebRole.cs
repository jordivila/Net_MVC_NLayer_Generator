using Microsoft.WindowsAzure.ServiceRuntime;

namespace AnotherServiceWebRole
{
    public class WebRole : RoleEntryPoint
    {
    }
}
