﻿using System;
using System.Linq;
using System.ServiceModel;
using SharedContractsLibrary;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace EntryPointService
{
    [ServiceBehavior(AddressFilterMode = AddressFilterMode.Any, 
                     ConfigurationName = "FrontEndService", 
                     Namespace = "http://windows.azure.com/samples/2012/02/services")]
    public class FrontEndService : IFrontEndService
    {
        public string CallBackEndBothOnInternalHttpEndpoint(string text)
        {
            return CallInstanceEndpoint("InternalHttp8082", text);
        }

        public string CallBackEndBothOnInternalTcpEndpoint(string text)
        {
            return CallInstanceEndpoint("InternalTcp9091", text);
        }

        public string CallBackEndInternalOnInternalHttpEndpoint(string text)
        {
            return CallInstanceEndpoint("InternalHttp8083", text);
        }

        public string CallBackEndInternalOnInternalTcpEndpoint(string text)
        {
            return CallInstanceEndpoint("InternalTcp9092", text);
        }

        private static string CallInstanceEndpoint(string endpointName, string text)
        {
            if (string.IsNullOrEmpty(endpointName))
            {
                throw new ArgumentException("The endpoint name cannot be null.");
            }
            string result = null;

            var instance = RoleEnvironment.Roles["BackEndBoth"].Instances.FirstOrDefault();

            if (instance != null)
            {
                // get the endpoint
                var endpoint = instance.InstanceEndpoints[endpointName].IPEndpoint;

                if (endpoint != null)
                {
                    string address;
                    ChannelFactory<IBackEndServiceChannel> factory;

                    if (endpointName.ToLower().Contains("http"))
                    {
                        address = string.Format(@"http://{0}/BackEndService.svc", endpoint.ToString());
                        factory = new ChannelFactory<IBackEndServiceChannel>(new BasicHttpBinding(), address);
                    }
                    else
                    {
                        address = string.Format(@"net.tcp://{0}/BackEndService.svc", endpoint.ToString());
                        factory = new ChannelFactory<IBackEndServiceChannel>(new NetTcpBinding()
                                                                                 {
                                                                                     Security = new NetTcpSecurity()
                                                                                                    {
                                                                                                        Mode = SecurityMode.None
                                                                                                    }
                                                                                 }, 
                                                                             address);
                    }

                    var channel = factory.CreateChannel();

                    try
                    {
                        result = channel.Echo(text);
                        channel.Close();
                        factory.Close();
                    }
                    finally
                    {
                        if (channel.State != CommunicationState.Closed)
                        {
                            channel.Abort();
                        }
                        if (factory.State != CommunicationState.Closed)
                        {
                            factory.Abort();
                        }
                    }
                }
            }
            return result;
        }
    }
}
