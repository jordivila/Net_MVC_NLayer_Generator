﻿using System.ServiceModel;

namespace EntryPointService
{
    [ServiceContract(ConfigurationName = "IFrontEndService", Namespace = "http://windows.azure.com/samples/2012/02/services")]
    public interface IFrontEndService
    {
        // BackEndBoth 
        [OperationContract(Action = "CallBackEndBothOnInternalHttpEndpoint")]
        string CallBackEndBothOnInternalHttpEndpoint(string text);

        [OperationContract(Action = "CallBackEndBothOnInternalTcpEndpoint")]
        string CallBackEndBothOnInternalTcpEndpoint(string text);

        // BackEndInternal
        [OperationContract(Action = "CallBackEndInternalOnInternalHttpEndpoint")]
        string CallBackEndInternalOnInternalHttpEndpoint(string text);

        [OperationContract(Action = "CallBackEndInternalOnInternalTcpEndpoint")]
        string CallBackEndInternalOnInternalTcpEndpoint(string text);
    }
}
