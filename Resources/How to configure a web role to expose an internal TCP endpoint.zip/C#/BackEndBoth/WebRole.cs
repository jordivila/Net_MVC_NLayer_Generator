using System.Diagnostics;
using System.IO;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace AnotherServiceWebRole
{
    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            var startInfo = new ProcessStartInfo()
            {
                FileName = "powershell.exe",
                Arguments = @".\setup\rolestart.ps1",
                RedirectStandardOutput = true,
                UseShellExecute = false,
            };

            var writer = new StreamWriter("psout.txt");

            var process = Process.Start(startInfo);
            process.WaitForExit();
            writer.Write(process.StandardOutput.ReadToEnd());
            writer.Close();

            return base.OnStart();
        }
    }
}
