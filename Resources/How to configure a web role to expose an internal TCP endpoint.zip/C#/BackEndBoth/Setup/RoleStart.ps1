﻿write-host "Begin RoleStart.ps1"

# Import the WebAdministration module
Import-Module WebAdministration 

# Start Net.Tcp Port Sharing Service 
$listenerService = Get-WmiObject win32_service -filter "name='NetTcpPortSharing'"
$listenerService.ChangeStartMode("Automatic")
$listenerService.StartService()

# Start the Net.Tcp Listener Adapter Service 
$listenerService = Get-WmiObject win32_service -filter "name='NetTcpActivator'"
$listenerService.ChangeStartMode("Automatic")
$listenerService.StartService()

# Add the tcp protocol to the BackEndBothSite and enable the net.tcp protocol on the root application
$WebRoleSite = (Get-WebSite "*BackEndBothSite*").Name
Set-ItemProperty "IIS:/Sites/$WebRoleSite/" -Name EnabledProtocols 'http,net.tcp'
New-ItemProperty "IIS:/Sites/$WebRoleSite" -name bindings -value @{protocol="net.tcp";bindingInformation="9091:*"}

# Add the tcp protocol to the BackEndInternalSite and enable the net.tcp protocol on the root application
$WebRoleSite = (Get-WebSite "*BackEndInternalSite*").Name
Set-ItemProperty "IIS:/Sites/$WebRoleSite/" -Name EnabledProtocols 'http,net.tcp'
New-ItemProperty "IIS:/Sites/$WebRoleSite" -name bindings -value @{protocol="net.tcp";bindingInformation="9092:*"}

write-host "End RoleStart.ps1"