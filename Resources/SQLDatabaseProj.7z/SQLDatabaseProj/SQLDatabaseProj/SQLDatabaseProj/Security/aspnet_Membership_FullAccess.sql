﻿CREATE ROLE aspnet_Membership_FullAccess

