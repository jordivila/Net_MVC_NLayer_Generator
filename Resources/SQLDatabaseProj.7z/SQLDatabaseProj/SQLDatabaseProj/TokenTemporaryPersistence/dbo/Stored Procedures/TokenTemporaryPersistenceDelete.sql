﻿Create procedure [dbo].TokenTemporaryPersistenceDelete
		@id as [varchar](255)
	as
	begin

		delete from [dbo].[TokenTemporaryPersistence] where tokenId = @id

		select @@rowcount

	end